public class Metadata {
    String[] tables;
    public Metadata() {

    }
}
